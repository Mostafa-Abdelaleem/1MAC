# Introduction to Statistical Learning with Python
All exercises with solutions in Python. Some notes and plot recreations as well.