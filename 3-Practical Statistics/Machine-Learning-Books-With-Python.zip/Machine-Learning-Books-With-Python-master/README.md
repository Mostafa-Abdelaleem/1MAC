# Master Machine Learning with Python

This repository contains some notes and exercises solutions for the following books:

* Introduction to Statistical Learning

If you are looking to become an expert, check out my books:

* [Exercise Python][0]
* [Master Data Analysis with Python][0]
* [Master Machine Learning with Python][0]

They are all extremely comprehensive and offer lots of exercises with detailed solutions.

[0]: https://www.dunderdata.com/store
